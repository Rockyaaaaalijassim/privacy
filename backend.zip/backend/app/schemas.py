from pydantic import BaseModel, Field

class AskRequest(BaseModel):
    question: str = Field(min_length=2, max_length=1000)
    document_ids: list[int] = []
