import re
from collections import defaultdict

TOPICS = {
    "data_collection": ["collect", "gather", "obtain", "personal information", "personal data", "معلومات شخصية", "نجمع", "جمع البيانات"],
    "location": ["location", "geolocation", "gps", "موقعك", "الموقع الجغرافي"],
    "cookies_tracking": ["cookie", "tracking", "pixels", "معرّفات", "ملفات تعريف الارتباط"],
    "sharing": ["share", "disclose", "third party", "third-party", "partners", "مشاركة", "أطراف ثالثة"],
    "purpose": ["purpose", "to provide", "for analytics", "advertising", "تحليل", "الإعلانات", "الغرض"],
    "retention": ["retain", "retention", "store for", "delete after", "احتفاظ", "فترة التخزين"],
    "security": ["security", "encrypt", "safeguard", "protect", "أمن", "حماية", "تشفير"],
    "user_rights": ["access", "delete", "erasure", "correct", "withdraw consent", "opt out", "حذف", "الوصول", "تصحيح"],
    "international_transfer": ["transfer outside", "international transfer", "cross-border", "خارج الدولة", "نقل دولي"],
}

RECIPIENTS = {
    "Google": ["google", "google analytics", "firebase"],
    "Meta": ["meta", "facebook", "instagram"],
    "Microsoft": ["microsoft", "azure"],
    "Amazon": ["amazon", "aws"],
    "Payment providers": ["payment processor", "payment providers", "stripe", "paypal"],
    "Advertising partners": ["advertising partners", "ad networks", "advertisers"],
    "Analytics providers": ["analytics providers", "analytics services"],
    "Cloud providers": ["cloud provider", "cloud hosting", "hosting provider"],
}

GDPR = [
    {"article":"5","title":"Principles relating to processing of personal data","topics":["data_collection","purpose","retention","sharing"],"note":"Relevant to transparency, purpose limitation, data minimisation and storage limitation."},
    {"article":"6","title":"Lawfulness of processing","topics":["purpose","data_collection"],"note":"Relevant when assessing whether a lawful basis is explained; policy text alone may not establish lawfulness."},
    {"article":"7","title":"Conditions for consent","topics":["user_rights","cookies_tracking"],"note":"Relevant where consent is relied upon."},
    {"article":"12","title":"Transparent information, communication and modalities","topics":["user_rights","data_collection","sharing"],"note":"Relevant to clear and accessible information for data subjects."},
    {"article":"13","title":"Information to be provided where personal data are collected from the data subject","topics":["data_collection","purpose","sharing","retention","user_rights","international_transfer"],"note":"Relevant to information provided at collection."},
    {"article":"14","title":"Information to be provided where personal data have not been obtained from the data subject","topics":["data_collection","purpose","sharing","retention"],"note":"Relevant where data are obtained from another source."},
    {"article":"15","title":"Right of access by the data subject","topics":["user_rights"],"note":"Relevant to access-right disclosures."},
    {"article":"17","title":"Right to erasure ('right to be forgotten')","topics":["user_rights"],"note":"Relevant to deletion-right disclosures."},
    {"article":"20","title":"Right to data portability","topics":["user_rights"],"note":"Relevant to portability-right disclosures."},
    {"article":"25","title":"Data protection by design and by default","topics":["security"],"note":"Relevant to design and default safeguards; policy text is not enough to verify implementation."},
    {"article":"32","title":"Security of processing","topics":["security"],"note":"Relevant to security measures; disclosures do not prove actual security."},
    {"article":"44","title":"General principle for transfers","topics":["international_transfer"],"note":"Relevant to transfers of personal data to third countries or international organisations."},
]

def split_sentences(text):
    # Keep this simple, predictable and evidence-oriented.
    return [s.strip() for s in re.split(r"(?<=[.!?؟])\s+|\n+", text) if len(s.strip()) > 20]

def analyze_text(text, doc_type, document_id=None):
    sentences = split_sentences(text)
    findings = []
    topic_sentences = defaultdict(list)
    for sentence in sentences:
        low = sentence.lower()
        for topic, terms in TOPICS.items():
            if any(term in low for term in terms):
                topic_sentences[topic].append(sentence)
    for topic, matches in topic_sentences.items():
        for sentence in matches[:12]:
            findings.append({
                "topic": topic,
                "title": topic.replace("_", " ").title() + " disclosure detected",
                "severity": "info",
                "explanation": f"The document contains wording related to {topic.replace('_',' ')}. Review the surrounding context to confirm what is disclosed.",
                "evidence": sentence,
                "document_type": doc_type,
                "document_id": document_id,
                "confidence": 0.72
            })

    recipients = []
    lower_text = text.lower()
    for recipient, terms in RECIPIENTS.items():
        hits = [term for term in terms if term in lower_text]
        if hits:
            matched = next((s for s in sentences if any(t in s.lower() for t in hits)), "")
            recipients.append({
                "name": recipient,
                "category": recipient if recipient in ("Google","Meta","Microsoft","Amazon") else recipient,
                "matched_terms": hits,
                "evidence": matched
            })

    mapped = []
    for article in GDPR:
        relevant = [f for f in findings if f["topic"] in article["topics"]]
        if relevant:
            mapped.append({
                "article": article["article"],
                "title": article["title"],
                "note": article["note"],
                "related_findings": len(relevant)
            })

    return {
        "document_type": doc_type,
        "findings": findings,
        "topics_detected": {k: len(v) for k, v in topic_sentences.items()},
        "recipients": recipients,
        "gdpr_mappings": mapped,
        "sentences_analyzed": len(sentences)
    }

def cross_document_analysis(documents):
    by_topic = defaultdict(list)
    for doc in documents:
        for finding in doc["result"].get("findings", []):
            by_topic[finding["topic"]].append({
                "document_type": doc["doc_type"],
                "evidence": finding["evidence"]
            })
    results = []
    expected = ["privacy_policy", "terms", "cookie_policy"]
    for topic, occurrences in by_topic.items():
        types = sorted(set(x["document_type"] for x in occurrences))
        if len(types) == 1 and topic in ("cookies_tracking","sharing","retention","user_rights","location"):
            results.append({
                "topic": topic,
                "kind": "limited_cross_document_coverage",
                "severity": "review",
                "message": f"{topic.replace('_',' ').title()} wording was detected in only one uploaded document type. This is a review prompt, not proof that another document must contain it.",
                "documents_found": types,
                "evidence": occurrences[:3]
            })
        elif len(types) > 1:
            results.append({
                "topic": topic,
                "kind": "cross_document_coverage",
                "severity": "info",
                "message": f"Related {topic.replace('_',' ')} disclosures appear across {len(types)} document types. Compare the passages for consistency.",
                "documents_found": types,
                "evidence": occurrences[:4]
            })
    return results

def transparency_score(result):
    # A simple, explainable coverage score. It measures disclosure coverage, not compliance.
    weights = {
        "data_collection": 20, "purpose": 15, "sharing": 15,
        "retention": 15, "user_rights": 15, "security": 10,
        "cookies_tracking": 5, "international_transfer": 5
    }
    topics = result.get("topics_detected", {})
    earned = sum(weight for topic, weight in weights.items() if topics.get(topic, 0) > 0)
    return round(earned, 1), {
        topic: {"weight": weight, "detected": topics.get(topic, 0) > 0}
        for topic, weight in weights.items()
    }
