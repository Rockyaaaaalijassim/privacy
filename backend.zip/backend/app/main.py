import json
import uuid
from pathlib import Path
from fastapi import FastAPI, Depends, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from .database import Base, engine, get_db, STORAGE
from .models import Document, Analysis
from .processor import extract_text
from .analyzer import analyze_text, cross_document_analysis, transparency_score, GDPR
from .schemas import AskRequest

Base.metadata.create_all(bind=engine)
app = FastAPI(title="Smart Policy Analyzer API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

ALLOWED_TYPES = {"privacy_policy", "terms", "cookie_policy"}
ALLOWED_EXTENSIONS = {".pdf", ".docx", ".txt"}

@app.get("/")
def root():
    return {"name": "Smart Policy Analyzer", "status": "running", "docs": "/docs"}

@app.get("/api/health")
def health():
    return {"status": "ok"}

@app.post("/api/documents")
async def upload_document(
    file: UploadFile = File(...),
    doc_type: str = Form(...),
    company: str = Form("Unknown company"),
    db: Session = Depends(get_db)
):
    if doc_type not in ALLOWED_TYPES:
        raise HTTPException(400, "Choose privacy_policy, terms, or cookie_policy.")
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(400, "Only PDF, DOCX, and TXT files are supported.")
    content = await file.read()
    if len(content) > 15 * 1024 * 1024:
        raise HTTPException(413, "File exceeds the 15 MB development limit.")
    safe_name = f"{uuid.uuid4().hex}{suffix}"
    path = STORAGE / safe_name
    path.write_bytes(content)
    try:
        text, pages = extract_text(path)
    except Exception as exc:
        path.unlink(missing_ok=True)
        raise HTTPException(422, str(exc))
    doc = Document(company=company[:200], doc_type=doc_type, filename=(file.filename or "upload")[:300], text=text)
    db.add(doc)
    db.commit()
    db.refresh(doc)
    result = analyze_text(text, doc_type, doc.id)
    score, breakdown = transparency_score(result)
    result["score"] = score
    result["score_breakdown"] = breakdown
    result["pages_extracted"] = len(pages)
    analysis = Analysis(document_id=doc.id, score=score, result_json=json.dumps(result, ensure_ascii=False))
    db.add(analysis)
    db.commit()
    return {"document_id": doc.id, "filename": doc.filename, "company": doc.company, "doc_type": doc.doc_type, "characters_extracted": len(text), "analysis": result}

@app.get("/api/documents")
def list_documents(db: Session = Depends(get_db)):
    docs = db.query(Document).order_by(Document.created_at.desc()).all()
    output = []
    for doc in docs:
        latest = db.query(Analysis).filter_by(document_id=doc.id).order_by(Analysis.created_at.desc()).first()
        output.append({
            "id": doc.id, "company": doc.company, "doc_type": doc.doc_type,
            "filename": doc.filename, "created_at": doc.created_at.isoformat(),
            "score": latest.score if latest else None
        })
    return output

@app.get("/api/documents/{document_id}")
def get_document(document_id: int, db: Session = Depends(get_db)):
    doc = db.get(Document, document_id)
    if not doc:
        raise HTTPException(404, "Document not found.")
    analysis = db.query(Analysis).filter_by(document_id=doc.id).order_by(Analysis.created_at.desc()).first()
    return {
        "id": doc.id, "company": doc.company, "doc_type": doc.doc_type,
        "filename": doc.filename, "text": doc.text,
        "analysis": json.loads(analysis.result_json) if analysis else None
    }

@app.delete("/api/documents/{document_id}")
def delete_document(document_id: int, db: Session = Depends(get_db)):
    doc = db.get(Document, document_id)
    if not doc:
        raise HTTPException(404, "Document not found.")
    db.delete(doc)
    db.commit()
    return {"deleted": document_id}

@app.get("/api/cross-analysis")
def get_cross_analysis(company: str | None = None, db: Session = Depends(get_db)):
    docs = db.query(Document).all()
    if company:
        docs = [d for d in docs if d.company.lower() == company.lower()]
    prepared = []
    for doc in docs:
        analysis = db.query(Analysis).filter_by(document_id=doc.id).order_by(Analysis.created_at.desc()).first()
        if analysis:
            prepared.append({"doc_type": doc.doc_type, "result": json.loads(analysis.result_json)})
    return {"documents_compared": len(prepared), "findings": cross_document_analysis(prepared)}

@app.get("/api/compare")
def compare_documents(first_id: int, second_id: int, db: Session = Depends(get_db)):
    rows = []
    for did in (first_id, second_id):
        doc = db.get(Document, did)
        if not doc:
            raise HTTPException(404, f"Document {did} not found.")
        analysis = db.query(Analysis).filter_by(document_id=did).order_by(Analysis.created_at.desc()).first()
        rows.append({"id": doc.id, "company": doc.company, "filename": doc.filename, "doc_type": doc.doc_type,
                     "analysis": json.loads(analysis.result_json) if analysis else {}})
    a, b = rows
    topics_a = set(a["analysis"].get("topics_detected", {}))
    topics_b = set(b["analysis"].get("topics_detected", {}))
    return {"first": a, "second": b, "added_topics": sorted(topics_b-topics_a), "removed_topics": sorted(topics_a-topics_b),
            "score_difference": (b["analysis"].get("score",0) - a["analysis"].get("score",0))}

@app.get("/api/gdpr")
def get_gdpr():
    return GDPR

@app.post("/api/assistant/ask")
def ask_assistant(request: AskRequest, db: Session = Depends(get_db)):
    docs = db.query(Document).all()
    if request.document_ids:
        docs = [d for d in docs if d.id in request.document_ids]
    if not docs:
        return {"answer": "Upload documents first so I can answer using their contents.", "evidence": []}
    q_terms = [w.lower() for w in request.question.split() if len(w) > 2]
    candidates = []
    for doc in docs:
        sentences = [s.strip() for s in doc.text.replace("\n", " ").split(".") if len(s.strip()) > 25]
        for sentence in sentences:
            low = sentence.lower()
            overlap = sum(1 for term in q_terms if term in low)
            if overlap:
                candidates.append((overlap, doc, sentence))
    candidates.sort(key=lambda x: x[0], reverse=True)
    top = candidates[:5]
    if not top:
        return {"answer": "I couldn't find a directly matching passage in the uploaded documents. Try asking with different wording. I won't guess beyond the available evidence.", "evidence": []}
    evidence = [{"document_id": d.id, "filename": d.filename, "doc_type": d.doc_type, "excerpt": s} for _, d, s in top]
    answer = "I found these relevant passages in your uploaded documents. They are evidence to review, not a legal conclusion:\n\n" + "\n\n".join(f"- {e['filename']}: {e['excerpt']}" for e in evidence)
    return {"answer": answer, "evidence": evidence}

@app.get("/api/companies")
def companies(db: Session = Depends(get_db)):
    docs = db.query(Document).all()
    names = sorted(set(d.company for d in docs))
    result = []
    for name in names:
        company_docs = [d for d in docs if d.company == name]
        scores = []
        for d in company_docs:
            a = db.query(Analysis).filter_by(document_id=d.id).order_by(Analysis.created_at.desc()).first()
            if a: scores.append(a.score)
        result.append({"company": name, "documents": len(company_docs), "average_score": round(sum(scores)/len(scores),1) if scores else 0})
    return result

@app.get("/api/reports/{document_id}")
def report(document_id: int, db: Session = Depends(get_db)):
    doc = db.get(Document, document_id)
    if not doc: raise HTTPException(404, "Document not found.")
    a = db.query(Analysis).filter_by(document_id=document_id).order_by(Analysis.created_at.desc()).first()
    return {"document": {"id":doc.id,"company":doc.company,"filename":doc.filename,"type":doc.doc_type},
            "analysis": json.loads(a.result_json) if a else {}}
