from pathlib import Path
import fitz
from docx import Document as DocxDocument

MAX_TEXT_CHARS = 2_000_000

def extract_text(path: Path) -> tuple[str, list[dict]]:
    suffix = path.suffix.lower()
    pages = []
    if suffix == ".pdf":
        with fitz.open(path) as pdf:
            for i, page in enumerate(pdf):
                text = page.get_text("text").strip()
                if text:
                    pages.append({"page": i + 1, "text": text})
    elif suffix == ".docx":
        doc = DocxDocument(path)
        text = "\n".join(p.text for p in doc.paragraphs if p.text.strip())
        if text:
            pages.append({"page": None, "text": text})
        for table in doc.tables:
            for row in table.rows:
                line = " | ".join(cell.text.strip() for cell in row.cells)
                if line.strip():
                    pages.append({"page": None, "text": line})
    elif suffix == ".txt":
        text = path.read_text(encoding="utf-8", errors="replace")
        pages.append({"page": None, "text": text})
    else:
        raise ValueError("Unsupported format. Upload PDF, DOCX, or TXT.")
    full_text = "\n\n".join(p["text"] for p in pages)[:MAX_TEXT_CHARS]
    if len(full_text.strip()) < 30:
        raise ValueError("Very little selectable text was extracted. This may be a scanned PDF; OCR is not included in this version.")
    return full_text, pages
